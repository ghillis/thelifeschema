# Node 06 Financial Plan

* Create Monthly Budget
* Create Back Accounts for automated flow
* Create Automatic Transfers